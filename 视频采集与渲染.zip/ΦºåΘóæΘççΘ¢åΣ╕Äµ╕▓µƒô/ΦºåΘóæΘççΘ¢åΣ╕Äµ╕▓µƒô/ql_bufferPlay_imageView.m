//
//  ql_bufferPlay_imageView.m
//  音频获取和播放demo
//
//  Created by 乔乐 on 2017/7/25.
//  Copyright © 2017年 乔乐. All rights reserved.
//

#import "ql_bufferPlay_imageView.h"
@interface ql_bufferPlay_imageView()
@property(nonatomic,assign) CVPixelBufferRef  tmp_pixelBuffer;
@property(nonatomic,assign) CGRect qlframe;

@end
@implementation ql_bufferPlay_imageView
- (instancetype)initWithFrame:(CGRect)frame and_touchBlock:(touchBlock)touch_block and_panBlcok:(panblock)pan_block
{
    if (self = [super initWithFrame:frame])
    {
        self.touch_block = touch_block;
        self.pan_block = pan_block;
        self.qlframe = frame;
        self.userInteractionEnabled = YES;
        [self createLayer];
        [self add_observer];
    }
    return self;
}

- (void)createLayer
{
    if (!self.buffer_layer)
    {
        self.buffer_layer = [[AVSampleBufferDisplayLayer alloc]init];
        self.buffer_layer.frame = self.bounds;
        self.buffer_layer.position = CGPointMake(CGRectGetMidX(self.bounds), CGRectGetMidY(self.bounds));
        /*!
         @constant		AVLayerVideoGravityResizeAspect  根据图像像素比例 绘制图像 图像会填充不满图层size
         @abstract		Preserve aspect ratio; fit within layer bounds.
         
         @constant		AVLayerVideoGravityResizeAspectFill  根据像素比例 填充图层 画面会超出图层size
         @abstract		Preserve aspect ratio; fill layer bounds.
         
         @constant		AVLayerVideoGravityResize   拉伸 用这个自适应不同size图层最好
         @abstract		Stretch to fill layer bounds.
         */
        self.buffer_layer.videoGravity = AVLayerVideoGravityResizeAspect;
        //不透明
        self.buffer_layer.opaque = YES;
        [self.layer addSublayer:self.buffer_layer];
    }
    else
    {
        [CATransaction begin];
        [CATransaction setDisableActions:YES];
        self.buffer_layer.bounds = self.qlframe;
        self.buffer_layer.position = CGPointMake(CGRectGetMidX(self.bounds), CGRectGetMidY(self.bounds));
        [CATransaction commit];
    }
}

#pragma mark - 监听后台
- (void)add_observer
{
    NSNotificationCenter * notificationCenter = [NSNotificationCenter defaultCenter];
    [notificationCenter addObserver: self selector:@selector(didResignActive) name:UIApplicationWillResignActiveNotification object:nil];
    [notificationCenter addObserver: self selector:@selector(didBecomeActive) name:UIApplicationDidBecomeActiveNotification object:nil];
}

- (void)didResignActive
{
    //[self show_backGroundImage];
}

- (void)didBecomeActive
{

}

#pragma mark - 显示缓存图片
- (void)show_backGroundImage
{
    if (self.tmp_pixelBuffer)
    {
        self.image = [self get_image_from_tmp];
        CFRelease(self.tmp_pixelBuffer);
        self.tmp_pixelBuffer = nil;
    }
}

- (UIImage*)get_image_from_tmp
{
    UIImage * ima = nil;
    CIImage * ciimage = [CIImage imageWithCVPixelBuffer:self.tmp_pixelBuffer];
    ima = [UIImage imageWithCGImage:(__bridge CGImageRef _Nonnull)(ciimage)];
    UIGraphicsBeginImageContext(self.bounds.size);
    [ima drawInRect:self.bounds];
    ima = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return ima;
}
#pragma mark - play
// 每来一帧数据进行缓存, 从后台模式返回后, 重启layer
- (void)play:(CMSampleBufferRef)buffer
{
    if (buffer)
    {
        [_buffer_layer enqueueSampleBuffer:buffer];
        if (_buffer_layer.status == AVQueuedSampleBufferRenderingStatusFailed)
        {
            //后台唤醒重启渲染层
            if (-11847 == _buffer_layer.error.code)
            {
                NSLog(@"11111");
                [self rebuildSampleBufferDisplayLayer];
            }
            else
            {
                [self rebuildSampleBufferDisplayLayer];
                NSLog(@"%s 第%d行 %@",__func__,__LINE__,_buffer_layer.error.description);
            }
        }
    }
}

#pragma mark - 重启渲染layer
- (void)rebuildSampleBufferDisplayLayer
{
    [self remove_layer];
    [self createLayer];
}

- (void)remove_layer
{
    if (self.buffer_layer)
    {
        [self.buffer_layer stopRequestingMediaData];
        [self.buffer_layer removeFromSuperlayer];
        self.buffer_layer = nil;
    }
}

- (void)dealloc
{
    if (self.tmp_pixelBuffer)
    {
        CFRelease(self.tmp_pixelBuffer);
        self.tmp_pixelBuffer = nil;
    }
}
@end
