//
//  audioAndVideo.h
//  音频获取和播放demo
//
//  Created by 乔乐 on 2017/4/17.
//  Copyright © 2017年 乔乐. All rights reserved.
//
#import <AVFoundation/AVFoundation.h>
typedef NS_ENUM(NSInteger, CaptureSessionPreset)
{
    CaptureSessionPreset640x480 = 0,
    CaptureSessionPresetiFrame960x540,
    CaptureSessionPreset1280x720,
    CaptureSessionPreset1920x1080
};

@protocol ql_VideDelegate<NSObject>
-(void)backWithVideobuffer:(CMSampleBufferRef)buffer andTimeStamp:(long long)pts;
@end

@interface ql_video_capture : NSObject
@property(nonatomic,assign)id<ql_VideDelegate>delegate;
- (instancetype)init;
- (void)startGetVideo;
- (void)stopGetVideo;
- (void)changeCamer;
@end
