//
//  audioAndVideo.m
//  音频获取和播放demo
//
//  Created by 乔乐 on 2017/4/17.
//  Copyright © 2017年 乔乐. All rights reserved.
//

#import "ql_video_capture.h"
@interface ql_video_capture()<AVCaptureVideoDataOutputSampleBufferDelegate>
@property(nonatomic,strong)AVCaptureDevice * videoDevice;
@property(nonatomic,strong)AVCaptureSession * videoSession;
@property(nonatomic,strong)AVCaptureVideoDataOutput * VideoOutput;
@property(nonatomic,strong)AVCaptureDeviceInput * VideoInput;
@property(nonatomic,strong)AVCaptureConnection * videoConnection;
@property(nonatomic,assign)NSInteger Position;
@property(nonatomic,assign)BOOL isComed;
@property(nonatomic,assign)long startTime;
@property(nonatomic,assign)long timeStamp;
@end
@implementation ql_video_capture


- (instancetype)init
{
    self = [super init];
    [self createVideoDeviceWithPosition:2];
    return self;
}

- (void)createVideoDeviceWithPosition:(NSInteger)position
{
    self.Position = position;
    //初始化AVCaptureSession
    self.videoSession =[[AVCaptureSession alloc]init];
    //开始配置
    [self.videoSession beginConfiguration];
    //设置分辨率
    [self set_capture_present];
     //获取视频设备对象
    self.videoDevice = [self cameraWithPosition:position];
    //初始化视频捕获输入对象
    self.VideoInput = [[AVCaptureDeviceInput alloc]initWithDevice:self.videoDevice error:nil];
    //初始化视频捕获输出对象
    self.VideoOutput = [[AVCaptureVideoDataOutput alloc]init];
    // 是否卡顿时丢帧
    [self.VideoOutput setAlwaysDiscardsLateVideoFrames:YES];
    // 设置像素格式
    self.VideoOutput.videoSettings =[NSDictionary dictionaryWithObject:[NSNumber numberWithInt:kCVPixelFormatType_420YpCbCr8BiPlanarFullRange] forKey:(id)kCVPixelBufferPixelFormatTypeKey];
    //将输出对象添加到队列、并设置代理
    dispatch_queue_t  mProcessQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0);
    [self.VideoOutput setSampleBufferDelegate:self queue:mProcessQueue];
    //输入,输出对象添加到Session
    if ([self.videoSession canAddInput:self.VideoInput])
    {
        [self.videoSession addInput:self.VideoInput];
    }
    if ([self.videoSession canAddOutput:self.VideoOutput])
    {
        [self.videoSession addOutput:self.VideoOutput];
    }
     //创建连接  AVCaptureConnection输入对像和捕获输出对象之间建立连接。
    _videoConnection=[self.VideoOutput connectionWithMediaType:AVMediaTypeVideo];
    //视频的方向
    [_videoConnection setVideoOrientation:AVCaptureVideoOrientationPortrait];
    //设置稳定性，判断connection连接对象是否支持视频稳定
    if ([_videoConnection isVideoStabilizationSupported]) {
        //这个稳定模式最适合连接
        _videoConnection.preferredVideoStabilizationMode = AVCaptureVideoStabilizationModeAuto;
    }
    //缩放裁剪系数
    _videoConnection.videoScaleAndCropFactor = _videoConnection.videoMaxScaleAndCropFactor;
    [self.videoSession commitConfiguration];
}

- (void)set_capture_present
{
        if (![self.videoDevice supportsAVCaptureSessionPreset:AVCaptureSessionPreset1920x1080])
        {
            if (![self.videoDevice supportsAVCaptureSessionPreset:AVCaptureSessionPreset1280x720])
            {
                if (![self.videoDevice supportsAVCaptureSessionPreset:AVCaptureSessionPresetiFrame960x540])
                {
                    if (![self.videoDevice supportsAVCaptureSessionPreset:AVCaptureSessionPreset640x480])
                    {
                        if (![self.videoDevice supportsAVCaptureSessionPreset:AVCaptureSessionPreset352x288])
                        {
                            NSLog(@"what the fuck?");
                        }else
                        {
                            self.videoSession.sessionPreset = AVCaptureSessionPreset352x288;
                        }
                    }else
                    {
                        self.videoSession.sessionPreset = AVCaptureSessionPresetiFrame960x540;
                    }
                }else
                {
                    self.videoSession.sessionPreset = AVCaptureSessionPresetiFrame960x540;
                }
            }else
            {
                self.videoSession.sessionPreset = AVCaptureSessionPreset1280x720;
            }
        }else
        {
            self.videoSession.sessionPreset = AVCaptureSessionPreset1920x1080;
        }

}

- (void)startGetVideo
{
    if (self.videoSession.running == 0)
    {
         [self.videoSession startRunning];
    }
}

- (void)stopGetVideo
{
    if (self.videoSession.running == 1)
    {
        [self.videoSession stopRunning];
    }
}

//切换摄像头哦
- (void)changeCamer
{
    [self.videoSession stopRunning];
    if (self.Position ==1)
    {
        [self createVideoDeviceWithPosition:2];
        self.Position = 2;
    }
    else
    {
        [self createVideoDeviceWithPosition:1];
        self.Position = 1;
    }
    [self.videoSession startRunning];
}
//视频采集数据回调
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection
{
    if (connection == self.videoConnection)
    {
        if (!self.isComed)
        {
            self.startTime = [[NSDate date] timeIntervalSince1970]*1000*1000;
            self.isComed = 1;
            self.timeStamp = 0;
            NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
            [defaults setInteger:self.startTime forKey:@"startTime"];
        }
        else
        {
            self.timeStamp = ([[NSDate date] timeIntervalSince1970]*1000*1000-self.startTime)*0.09;
        }
        [self.delegate backWithVideobuffer:sampleBuffer andTimeStamp:self.timeStamp];
    }
}
//切换摄像头
- (AVCaptureDevice *)cameraWithPosition:(AVCaptureDevicePosition)position
{
    NSArray *devices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    for ( AVCaptureDevice *device in devices )
        if ( device.position == position )
        {
            return device;
        }
    return nil;
}
@end
