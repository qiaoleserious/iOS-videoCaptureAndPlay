//
//  ql_bufferPlay_smallImageView.m
//  BVCforIphone
//
//  Created by 乔乐 on 2017/7/26.
//  Copyright © 2017年 乔乐. All rights reserved.
//

#import "ql_bufferPlay_smallImageView.h"

@implementation ql_bufferPlay_smallImageView
- (instancetype)initWithFrame:(CGRect)frame and_touchBlock:(touchBlock)touch_block and_panBlcok:(panblock)pan_block
{
    if (self = [super initWithFrame:frame and_touchBlock:touch_block and_panBlcok:pan_block])
    {
        UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
        [self addGestureRecognizer:tap];
        UIPanGestureRecognizer * pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(pan:)];
        [self addGestureRecognizer:pan];
    }
    return self;
}

- (void)tap:(UITapGestureRecognizer*)tap
{
     // 切换大小屏时,在此block内 调用flushAndRemoveImage 清除缓存
    self.touch_block();
}

- (void)pan:(UIPanGestureRecognizer*)pan
{
    self.pan_block(pan);
}

@end
