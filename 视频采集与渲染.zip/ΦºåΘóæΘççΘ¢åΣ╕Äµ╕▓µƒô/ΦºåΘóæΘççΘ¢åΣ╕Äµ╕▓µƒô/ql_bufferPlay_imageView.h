//
//  ql_bufferPlay_imageView.h
//  音频获取和播放demo
//
//  Created by 乔乐 on 2017/7/25.
//  Copyright © 2017年 乔乐. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
typedef void(^touchBlock)();
typedef void(^panblock)(UIPanGestureRecognizer * pan);
@interface ql_bufferPlay_imageView : UIImageView
@property(nonatomic,copy)touchBlock touch_block;
@property(nonatomic,copy)panblock pan_block;
@property(nonatomic,strong) AVSampleBufferDisplayLayer * buffer_layer;
- (instancetype)initWithFrame:(CGRect)frame and_touchBlock:(touchBlock)touch_block and_panBlcok:(panblock)pan_block;
- (void)play:(CMSampleBufferRef)buffer;
@end
