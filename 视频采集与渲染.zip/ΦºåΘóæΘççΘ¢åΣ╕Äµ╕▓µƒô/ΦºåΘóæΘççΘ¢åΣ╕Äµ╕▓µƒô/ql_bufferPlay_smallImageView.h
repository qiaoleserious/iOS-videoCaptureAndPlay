//
//  ql_bufferPlay_smallImageView.h
//  BVCforIphone
//
//  Created by 乔乐 on 2017/7/26.
//  Copyright © 2017年 乔乐. All rights reserved.
//

#import "ql_bufferPlay_imageView.h"

@interface ql_bufferPlay_smallImageView : ql_bufferPlay_imageView

@end
