//
//  ViewController.h
//  视频采集与渲染
//
//  Created by 乔乐 on 2017/8/21.
//  Copyright © 2017年 乔乐. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

