//
//  ViewController.m
//  视频采集与渲染
//
//  Created by 乔乐 on 2017/8/21.
//  Copyright © 2017年 乔乐. All rights reserved.
//

#import "ViewController.h"
#import "ql_video_capture.h"
#import "ql_bufferPlay_smallImageView.h"
@interface ViewController ()<ql_VideDelegate>
@property(nonatomic,strong)ql_bufferPlay_imageView * big_image;
@property(nonatomic,strong)ql_bufferPlay_smallImageView * small_image;
@property(nonatomic,assign)BOOL isSmall;
@property(nonatomic,strong)ql_video_capture * video_capture;
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    //采集
    _video_capture = [[ql_video_capture alloc]init];
    _video_capture.delegate = self;
    //渲染大图
    _big_image = [[ql_bufferPlay_imageView alloc]initWithFrame:self.view.frame and_touchBlock:^{
    } and_panBlcok:^(UIPanGestureRecognizer *pan)
    {
    }];
    [self.view addSubview:_big_image];
    //渲染小图
    _small_image = [[ql_bufferPlay_smallImageView alloc]initWithFrame:CGRectMake(250, 100, 100, 200) and_touchBlock:^{
        self.isSmall = !self.isSmall;
        [self players_flush_and_remove_image];
    } and_panBlcok:^(UIPanGestureRecognizer *pan)
    {
        if (pan.state==UIGestureRecognizerStateChanged)
        {
            CGPoint translation=[pan translationInView:self.view];//利用拖动手势的translationInView:方法取得在相对指定视图（这里是控制器根视图）的移动
            self.small_image.center = CGPointMake(self.small_image.center.x+translation.x, self.small_image.center.y+translation.y);
            [pan setTranslation:CGPointZero inView:self.view];
        }
    }];
    [self.view addSubview:self.small_image];
    
    self.view.backgroundColor = [UIColor whiteColor];
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    [btn setTitle:@"开始采集" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    btn.backgroundColor = [UIColor clearColor];
    [btn addTarget:self action:@selector(btn) forControlEvents:UIControlEventTouchUpInside];
    _small_image.backgroundColor = [UIColor purpleColor];
    [self.view addSubview:btn];
}

- (void)btn
{
    [_video_capture startGetVideo];
}

- (void)players_flush_and_remove_image
{
    [self.big_image.buffer_layer flushAndRemoveImage];
    [self.small_image.buffer_layer flushAndRemoveImage];
}

-(void)backWithVideobuffer:(CMSampleBufferRef)buffer andTimeStamp:(long long)pts
{
    if (self.isSmall)
    {
        [self.small_image play:buffer];
    }
    else
    {
        [self.big_image play:buffer];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
